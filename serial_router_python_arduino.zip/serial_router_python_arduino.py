from tkinter import *
from tkinter.ttk import *
import serial.tools.list_ports

arduinoData = serial.Serial(port="COM3", baudrate=9600, timeout=0.1)
#arduinoData.baudrate = 9600
#arduinoData.port = "COM3" !!!configure the correct port for usecase!!!



class MainPageFrame:
    def __init__(self):
        #style shit :D
        self.window = Tk()
        self.window.title("SERIAL ROUTER")
        self.window.geometry("480x230+500+100")
        self.window.resizable(False, False)

        self.main_page_frame = Frame(self.window, width=500, height=300)
        self.main_page_frame.pack()

        self.welcome_label = Label(self.main_page_frame, text="WELCOME USER")
        self.welcome_label.place(x=177, y=20)

        self.value1_label = Label(self.main_page_frame, text="Value 1:")
        self.value1_label.place(x=50, y=70)

        self.value1_entry = Entry(self.main_page_frame, width=36)
        self.value1_entry.place(x=130, y=70)
        self.value1_entry.focus()

        self.value2_label = Label(self.main_page_frame, text="PORT (COM3):")
        self.value2_label.place(x=50, y=120)

        self.value2_entry = Entry(self.main_page_frame, width=36)
        self.value2_entry.place(x=130, y=120)

        self.the_button = Button(self.main_page_frame, text="PROCESS", width=15, command=self.the_button_function)
        self.the_button.place(x=180, y=180)
        
        self.port_button = Button(self.main_page_frame, text="PORT OK", width=15, command=self.port_button_function)
        self.port_button.place(x=180, y=150)

        self.window.mainloop()

    # whenever the button is pressed this function will work
    def the_button_function(self):

        value1 = self.value1_entry.get()
        print(value1)
        arduinoData.write(bytes(value1, "utf-8"))

    def port_button_function(self):
        value2 = self.value2_entry.get()
        print(value2)



MainPageFrame()
